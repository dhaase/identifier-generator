# identifier-generator
A transient 64 bit identifier-generator
